﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Character : Unit
{

    [SerializeField]
    public int lives = 1;

    public int Lives
    {
        get { return lives; }
        set
        {
            if (value < 1) lives = value;
            livesBar.Refresh();
        }
    }
    private LivesBar livesBar;
    [SerializeField]
    private float speed = 3.0F;

    [SerializeField]
    private float jumpForce = 10.0F;


    public CharState State
    {
        get { return (CharState)animator.GetInteger("State"); }
        set { animator.SetInteger("State", (int) value); }
    }
    new private Rigidbody2D rigidbody;
    private Animator animator;
    private SpriteRenderer sprite;
    private bool isGrounded = false;



    public override void ReceiveDamage()
    {
        Lives--;
        if (lives <= 0)// если жизней меньше либо равно нулю
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        
        rigidbody.velocity = Vector3.zero;
        rigidbody.AddForce(transform.up * 4.0F, ForceMode2D.Impulse);
        Debug.Log(lives);
        
    }


    private void Awake()
    {
        livesBar = FindObjectOfType<LivesBar>();
        rigidbody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        sprite = GetComponentInChildren<SpriteRenderer>();
    }
    private void FixedUpdate()
    {
        ChekGround();
    }
    private void Update()
    {
        if (isGrounded)State = CharState.Stand;



        if (Input.GetButton("Horizontal")) Run();
        if (isGrounded && Input.GetButtonDown("Jump")) Jump();
    }
    private void Run()
    {
        Vector3 direction = transform.right * Input.GetAxis("Horizontal");

        transform.position = Vector3.MoveTowards(transform.position, transform.position + direction, speed * Time.deltaTime);
        sprite.flipX = direction.x < 0.0F;

        if(isGrounded) State = CharState.Run ;
    }
    private void Jump()
    {
        rigidbody.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);
    }
    private void ChekGround()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, 1.5F);

        isGrounded = colliders.Length > 1;
    }
}

public enum CharState
{
    Stand,   //0
    Run,     //1
    Jump,    //2
    TakeDamage,   //3
}
